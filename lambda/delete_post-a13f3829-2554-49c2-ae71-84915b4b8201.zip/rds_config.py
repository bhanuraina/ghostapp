#config file containing credentials for RDS MySQL instance
db_username = "ghostadmin"
db_password = "Ghost#1234"
db_name = "mydb" 